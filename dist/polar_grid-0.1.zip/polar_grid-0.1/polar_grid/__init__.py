"""
Copyright (c) 2012 Michael Markieta
See the file license.txt for copying permission.
"""
from polar_grid import *
